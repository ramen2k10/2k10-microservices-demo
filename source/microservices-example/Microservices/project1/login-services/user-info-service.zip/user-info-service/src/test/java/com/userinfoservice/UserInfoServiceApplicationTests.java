package com.userinfoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
